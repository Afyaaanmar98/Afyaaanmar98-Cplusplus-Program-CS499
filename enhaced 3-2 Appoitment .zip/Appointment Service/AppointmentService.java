/*************************
 * Name:    Afyaa  
 * Course:  CS-320 
 * Date:    June 2, 2025
 * Description: This is the AppointmentService class. It maintains appointments and provides 
 * functionality to add, update, and delete appointments using an in-memory list.
 *************************/

package Appointment;

import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {

    // In-memory storage for appointments
    private ArrayList<Appointment> appointmentList = new ArrayList<>();

    /**
     * Adds a new appointment to the list.
     */
    public void addAppointment(Date appointmentDate, String appointmentDesc) {
        Appointment appointment = new Appointment(appointmentDate, appointmentDesc);
        appointmentList.add(appointment);
    }

    /**
     * Returns appointment by ID.
     */
    public Appointment getAppointment(String appointmentID) {
        return findAppointmentById(appointmentID);
    }

    /**
     * Deletes appointment by ID.
     */
    public void deleteAppointment(String appointmentID) {

        Appointment appointment = findAppointmentById(appointmentID);

        if (appointment == null) {
            throw new IllegalArgumentException("Appointment ID: " + appointmentID + " not found.");
        }

        appointmentList.remove(appointment);
    }

    /**
     * Updates appointment date by ID.
     */
    public void updateAppointmentDate(Date updatedDate, String appointmentID) {

        Appointment appointment = findAppointmentById(appointmentID);

        if (appointment == null) {
            throw new IllegalArgumentException("Appointment ID: " + appointmentID + " not found.");
        }

        appointment.setAppointmentDate(updatedDate);
    }

    /**
     * Updates appointment description by ID.
     */
    public void updateAppointmentDesc(String updatedDesc, String appointmentID) {

        Appointment appointment = findAppointmentById(appointmentID);

        if (appointment == null) {
            throw new IllegalArgumentException("Appointment ID: " + appointmentID + " not found.");
        }

        appointment.setAppointmentDesc(updatedDesc);
    }

    /**
     * Returns number of appointments in system.
     */
    public int getAppointmentCount() {
        return appointmentList.size();
    }

    /**
     * Helper method to find appointment by ID.
     */
    private Appointment findAppointmentById(String appointmentID) {

        for (Appointment appointment : appointmentList) {
            if (appointment.getAppointmentID().equals(appointmentID)) {
                return appointment;
            }
        }

        return null;
    }

    /**
     * Debug display method.
     */
    public void displayAppointments() {

        for (Appointment appointment : appointmentList) {
            System.out.println("\tAppointment ID: " + appointment.getAppointmentID());
            System.out.println("\tAppointment Date: " + appointment.getAppointmentDate());
            System.out.println("\tAppointment Description: " + appointment.getAppointmentDesc());
        }
    }
}