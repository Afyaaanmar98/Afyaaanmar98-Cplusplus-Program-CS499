/*************************
 * Name:    Afyaa 
 * Course:  CS-320 
 * Date:    June 2, 2025
 * Description: This is the test class for Appointment. It validates the Appointment class 
 * functionality including ID length, date validity, and description constraints.
 *************************/

package Test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import java.util.Calendar;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import Appointment.Appointment;

class AppointmentTest {

    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 5);
        return cal.getTime();
    }

    @Test
    @DisplayName("Appointment ID should not exceed 10 characters")
    void testAppointmentIDMaxLength() {

        Appointment appointment = new Appointment(getFutureDate(), "Test Description");

        assertTrue(appointment.getAppointmentID().length() <= 10);
    }

    @Test
    @DisplayName("Appointment description should not exceed 50 characters")
    void testAppointmentDescMaxLength() {

        String longDescription = "123456789-123456789-123456789-123456789-123456789-EXTRA";

        Appointment appointment = new Appointment(getFutureDate(), longDescription);

        assertTrue(appointment.getAppointmentDesc().length() <= 50);
    }

    @Test
    @DisplayName("Appointment date cannot be in the past")
    void testAppointmentDateInPast() {

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -5);

        Date pastDate = cal.getTime();

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(pastDate, "Description");
        });
    }

    @Test
    @DisplayName("Appointment date cannot be null")
    void testAppointmentDateNotNull() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, "Valid Description");
        });
    }

    @Test
    @DisplayName("Appointment description cannot be null")
    void testAppointmentDescNotNull() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(getFutureDate(), null);
        });
    }
}