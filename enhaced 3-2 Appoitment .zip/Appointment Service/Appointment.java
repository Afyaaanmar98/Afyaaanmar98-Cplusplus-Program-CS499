/*************************
 * Name:    Afyaa  
 * Course:  CS-320 
 * Date:    June 2, 2025
 * Description: This is the Appointment class. It creates and manages appointment information,
 *              including unique ID, valid future date, and a short description.
 *************************/

package Appointment;

import java.util.concurrent.atomic.AtomicLong;
import java.util.Date;

public class Appointment {

    private static final int MAX_DESCRIPTION_LENGTH = 50;

    private final String appointmentID;
    private Date appointmentDate;
    private String appointmentDesc;
    private static AtomicLong idGenerator = new AtomicLong();

    /**
     * Constructor that initializes the appointment with a unique ID,
     * valid future date, and description.
     */
    public Appointment(Date appointmentDate, String appointmentDesc) {
        this.appointmentID = String.valueOf(idGenerator.getAndIncrement());
        setAppointmentDate(appointmentDate);
        setAppointmentDesc(appointmentDesc);
    }

    public String getAppointmentID() {
        return appointmentID;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public String getAppointmentDesc() {
        return appointmentDesc;
    }

    /**
     * Sets appointment date. Date must not be null or in the past.
     */
    public void setAppointmentDate(Date appointmentDate) {

        if (appointmentDate == null) {
            throw new IllegalArgumentException("Appointment date cannot be null.");
        }

        if (appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date cannot be in the past.");
        }

        this.appointmentDate = appointmentDate;
    }

    /**
     * Sets appointment description. Must not be null or empty.
     * Truncates if longer than max length.
     */
    public void setAppointmentDesc(String appointmentDesc) {

        if (appointmentDesc == null || appointmentDesc.trim().isEmpty()) {
            throw new IllegalArgumentException("Appointment description cannot be null or empty.");
        }

        if (appointmentDesc.length() > MAX_DESCRIPTION_LENGTH) {
            this.appointmentDesc = appointmentDesc.substring(0, MAX_DESCRIPTION_LENGTH);
        } else {
            this.appointmentDesc = appointmentDesc;
        }
    }
}