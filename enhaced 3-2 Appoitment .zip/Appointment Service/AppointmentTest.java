/*************************
 * Name:    Afyaa 
 * Course:  CS-320 
 * Date:    June 2, 2025
 * Description: This is the test class for Appointment. It validates the Appointment class 
 * functionality including ID length, date validity, and description constraints.
 *************************/

package Test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import java.util.Calendar;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import Appointment.Appointment;

class AppointmentTest {

    // Helper method to create a future date for testing
    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 5);
        return cal.getTime();
    }

    @Test
    @DisplayName("Appointment ID should not exceed 10 characters")
    void testAppointmentIDMaxLength() {
        Appointment appointment = new Appointment(getFutureDate(), "Test Description");
        assertTrue(appointment.getAppointmentID().length() <= 10,
                "Appointment ID has more than 10 characters.");
    }

    @Test
    @DisplayName("Appointment description should be 50 characters or less")
    void testAppointmentDescMaxLength() {
        String longDescription = "123456789-123456789-123456789-123456789-123456789-EXTRA";
        Appointment appointment = new Appointment(getFutureDate(), longDescription);
        assertTrue(appointment.getAppointmentDesc().length() <= 50,
                "Appointment description exceeds 50 characters.");
    }

    @Test
    @DisplayName("Appointment date must not be in the past")
    void testAppointmentDateInPast() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -5);
        Date pastDate = cal.getTime();

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(pastDate, "Description");
        }, "Allowed appointment date to be in the past.");
    }

    @Test
    @DisplayName("Appointment date must not be null")
    void testAppointmentDateNotNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, "Valid Description");
        }, "Allowed appointment date to be null.");
    }

    @Test
    @DisplayName("Appointment description must not be null")
    void testAppointmentDescNotNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(getFutureDate(), null);
        }, "Allowed appointment description to be null.");
    }

    @Test
    @DisplayName("Appointment description must not be empty")
    void testAppointmentDescNotEmpty() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(getFutureDate(), "");
        }, "Allowed appointment description to be empty.");
    }
}