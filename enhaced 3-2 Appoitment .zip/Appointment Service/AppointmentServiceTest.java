package Test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import Appointment.Appointment;
import Appointment.AppointmentService;

class AppointmentServiceTest {

    private Date getFutureDate(int year, int month, int day) {

        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, day);

        return calendar.getTime();
    }

    @Test
    @DisplayName("Test to add an appointment")
    void testAddAppointment() {

        AppointmentService service = new AppointmentService();

        service.addAppointment(getFutureDate(2026, Calendar.MAY, 20), "New Appointment");

        assertEquals(1, service.getAppointmentCount());
    }

    @Test
    @DisplayName("Test to update appointment date")
    void testUpdateAppointmentDate() {

        AppointmentService service = new AppointmentService();

        Date originalDate = getFutureDate(2026, Calendar.JANUARY, 1);
        Date updatedDate = getFutureDate(2027, Calendar.FEBRUARY, 2);

        service.addAppointment(originalDate, "Initial Description");

        Appointment appointment = service.getAppointment("0");

        service.updateAppointmentDate(updatedDate, appointment.getAppointmentID());

        assertEquals(updatedDate, service.getAppointment(appointment.getAppointmentID()).getAppointmentDate());
    }

    @Test
    @DisplayName("Test to delete an appointment")
    void testDeleteAppointment() {

        AppointmentService service = new AppointmentService();

        service.addAppointment(getFutureDate(2026, Calendar.APRIL, 10), "Delete Me");

        Appointment appointment = service.getAppointment("0");

        service.deleteAppointment(appointment.getAppointmentID());

        assertEquals(0, service.getAppointmentCount());
    }

    @Test
    @DisplayName("Deleting invalid appointment should throw exception")
    void testDeleteInvalidAppointment() {

        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("999");
        });
    }
}